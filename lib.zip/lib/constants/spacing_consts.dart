class SpacingConsts{
  SpacingConsts._();

  static const double kDefaultPadding = 20.0;
}