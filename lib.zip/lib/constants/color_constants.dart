import 'package:flutter/material.dart';

class ColorConstants {
  ColorConstants._();

  static const Color primaryCOlor = Color(0xFF295BE0);
  static const Color accentCOlor = Color(0xFFFFC157);
}